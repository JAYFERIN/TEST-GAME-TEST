﻿define Azpy = Character("Azpy", color="#ffffff", image="azpy omg kill it")

label start:
    scene dont you kno pump it up
    pause
    show azpy omg kill it
    pause
    show azpy durr
    Azpy "Waddup everyone"
    Azpy "It yo budddaayyy lmao lmao"
    Azpy "Wats tis?"
    Azpy "dude idfk"
    Azpy "just trying new bullshit at 3 am lmaoalmaoaa"
    show azpy eyes
    Azpy "anyway yohoho"
    Azpy "whats youyor name brochacho"
    $ y = renpy.input("Whats yo name brochacho")
    if y == "":
        $ y = "brochacho"
    show azpy durr
    Azpy "ayeee dap me uo [y]!"
    Azpy "oh shit i dont have a sprite for dapping tho lmaolmalaomalmao"
    Azpy "annyyyywaaayyyyyssssss broskisssssssss"
    show azpy omg kill it
    pause
    Azpy "ya see this little shit????"
    Azpy "I want you to do something to it cuz iont like it"
    pause

    menu:
        "do you wanna kill it or nah"

        "omg ewwwww kill it":
            $ choice1 = "killit"
            jump killit

        "nahhhh lmao":
            $ choice2 = "nokill"
            jump nokill


label killit:
    show azpy omg kill it
    pause
    Azpy "amazing"
    Azpy "you made da good choice buddy ohoh"
    show creature explode
    pause
    scene happy ending scene
    with fade
    "turns out this creature was very very very evil and plotted to kill you ruhroh"
    "making this choice saved your life, hero"
    "you lived to see another day"
    "{b}Good ending{/b}."
    return

    label nokill:
    show azpy durr
    pause
    Azpy "..."
    Azpy "too bad buddy"
    Azpy "im gonna have to explode you neow aww"
    scene explosion
    with fade
    pause
    "{b}what the hell is going on Ending{/b}."
    return